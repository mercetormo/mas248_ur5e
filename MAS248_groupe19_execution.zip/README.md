# MAS248 · UR5e réel · groupe 19

Ce complément ajoute l'exécution supervisée à `mas248_ur5e_real` et prépare un JSON à partir du contour testé. Tous les terminaux ROS de l'essai utilisent `ROS_DOMAIN_ID=19`.

Le fichier `circle_80_reference.json` reconstruit le cercle nominal pour les vérifications hors ligne. Il contient 80 poses, avec un diamètre d'environ 90,2 mm et une hauteur TCP nominale de 3 mm. Les points ont été reconstruits analytiquement. Pour comparer avec le même contour qu'en simulation, partez du JSON OpenCV original du groupe.

## Installer le complément

Décompressez l'archive dans `~/mas248_l10_groupe19` ou adaptez `BUNDLE`. Le correctif est prévu pour la version du paquet fournie au groupe le 9 novembre. Vérifiez son application à la racine de votre dépôt.

```bash
BUNDLE="$HOME/mas248_l10_groupe19"
REPO="$HOME/mas248_ws/src/mas248_ur5e"
git -C "$REPO" apply --check "$BUNDLE/mas248_l10_execution.patch" &&
git -C "$REPO" apply "$BUNDLE/mas248_l10_execution.patch"
```

Une fois le correctif appliqué, compilez et testez le JSON de référence.

```bash
source /opt/ros/humble/setup.bash
cd "$HOME/mas248_ws"
colcon build --packages-up-to mas248_ur5e_real &&
source install/setup.bash &&
ros2 run mas248_ur5e_real run_picture_real.py \
  --targets "$BUNDLE/circle_80_reference.json" --validate-only
```

## Préparer le JSON au poste

Relevez avec l'enseignant le centre de l'image dans `world`, la hauteur de la feuille et la hauteur TCP retenue pour l'essai. Toutes les valeurs sont en mètres avec un point décimal. Le générateur suppose une feuille horizontale. Pour le survol et le dessin, choisissez deux hauteurs validées et enregistrez les deux fichiers séparément.

Le premier chemin ci-dessous correspond à l'essai simulé. Si besoin, utilisez la copie du dépôt à `mas248_ur5e_real/examples/circle/targets.json`. Le fichier nominal de l'archive est également utilisable comme source si vous acceptez de partir du cercle reconstruit.

```bash
SOURCE="$HOME/mas248_ws/results/workcell_v2_circle/targets.json"
RESULTS="$HOME/mas248_ws/results/workcell_v2_circle"
read -r -p 'Centre image X Y dans world, en mètres (deux nombres) : ' CENTER_X CENTER_Y
read -r -p 'Z feuille et Z TCP validé dans world, en mètres (deux nombres) : ' PAPER_Z TCP_Z

ros2 run mas248_ur5e_real prepare_circle_targets.py \
  --source "$SOURCE" --output "$RESULTS/circle_real.json" \
  --center-x "$CENTER_X" --center-y "$CENTER_Y" \
  --paper-z "$PAPER_Z" --tcp-z "$TCP_Z"
```

Pour préparer le survol, utilisez le même outil avec la hauteur de survol et `--output "$RESULTS/circle_hover.json"`. Les dimensions du contour et les orientations TCP sont reprises du fichier source.

## Planification et essai supervisé

Dans **chaque** terminal ROS du groupe :

```bash
source /opt/ros/humble/setup.bash
source "$HOME/mas248_ws/install/setup.bash"
export ROS_DOMAIN_ID=19
```

Faites confirmer les adresses du poste par l'enseignant. Les exemples utilisent le robot `192.168.1.101` et le PC `192.168.1.102`. Le pilote se lance en premier, MoveIt en deuxième, puis External Control au pupitre selon la procédure du labo. Vérifiez `Calibration checked successfully` dans le log du pilote.

Pour le précontrôle, gardez `enable_execution:=false` dans les deux commandes de lancement ci-dessous. Ouvrez RViz avant de planifier.

```bash
ros2 run mas248_ur5e_real preflight.py \
  --calibration "$HOME/ur5e_calibration.yaml" \
  --targets "$HOME/mas248_ws/results/workcell_v2_circle/circle_real.json" \
  --max-strokes 1
```

Avec l'enseignant, relancez le pilote et MoveIt avec `enable_execution:=true` pour l'essai. Conservez les mêmes paramètres matériels et la calibration dans les deux terminaux.

Terminal 1 :

```bash
ros2 launch mas248_ur5e_real driver.launch.py \
  robot_ip:=192.168.1.101 reverse_ip:=192.168.1.102 \
  calibration:="$HOME/ur5e_calibration.yaml" \
  enable_execution:=true acknowledge_hardware:=yes
```

Terminal 2 :

```bash
ros2 launch mas248_ur5e_real moveit_real.launch.py \
  robot_ip:=192.168.1.101 reverse_ip:=192.168.1.102 \
  calibration:="$HOME/ur5e_calibration.yaml" \
  enable_execution:=true launch_rviz:=true
```

Terminal 3 :

```bash
ros2 run mas248_ur5e_real run_picture_real.py \
  --targets "$HOME/mas248_ws/results/workcell_v2_circle/circle_real.json" \
  --calibration "$HOME/ur5e_calibration.yaml" --max-strokes 1 \
  --execute --acknowledge-hardware --acknowledge-clearance
```

Utilisez d'abord le fichier de survol si c'est l'essai convenu. Le script calcule le plan complet, le publie dans RViz et attend la saisie de `EXECUTE`. Revoyez ce plan avec l'enseignant avant de confirmer. Le script compare l'état articulaire lu au début attendu de chaque segment et s'arrête en cas d'échec. Suivez la procédure d'arrêt du labo au pupitre si le mouvement s'écarte de l'essai prévu.

Pour le rapport, conservez le JSON effectivement utilisé, le log de planification et d'exécution, la capture RViz et le résultat filmé ou photographié. Ce complément a été vérifié hors ligne sur la copie du paquet. L'essai sur le UR5e et la géométrie du poste restent à valider au labo.
